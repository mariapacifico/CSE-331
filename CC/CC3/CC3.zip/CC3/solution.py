"""
CC3 Student Submission
Name:
"""

from typing import List, Tuple


def calculate(participants: List[str], character_details: List[Tuple[str, str, int]]) \
        -> List[Tuple[str, int]]:
    """
    docstring: PLEASE fill it here,
    example is on CC1
    """

    # 1. change names in list to english

    # create dictionary for jap to english names : dict_jap_names[jap name] = english name
    dict_jap_names = {}
    for i in character_details:
        # the first index isn't the japaneese name
        if i[0].isascii():
            dict_jap_names[i[1]] = i[0]

        # is the japaneese name
        else:
            dict_jap_names[i[0]] = i[1]

    # create dictionary for english to jap names : dict_jap_names[eng name] = jap nam
    dict_eng_names = {}
    for i in character_details:
        # the first index is the english name
        if i[0].isascii():
            dict_eng_names[i[0]] = i[1]

        # is the japaneese name
        else:
            dict_eng_names[i[1]] = i[0]

    # iterate through list to check, change to english names
    for i in range(len(participants)):
        # the name is jap
        if participants[i] in dict_jap_names:
            participants[i] = dict_jap_names[participants[i]] # get the english name from the dict, change in the list


    # 2. create dictionary : dict_points[english name] = points
    dict_points = {}

    for i in character_details:
        if i[0] in dict_jap_names:
            dict_points[i[1]] = i[2]

        # is the english name
        else:
            dict_points[i[0]] = i[2]


    # 3. get the scores
    final_scores = []
    #stack = []

    # add names to final
    for i in participants:
        # ADD JAP NAMES IF SCORE IS LARGER THAN 9000
        if dict_points[i] > 9000:
            final_scores.append((dict_eng_names[i], 0))
        else:
            final_scores.append((i, 0))

    stack = []
    for index in range(len(participants)):
        # add to stack if empty
        if stack == []:

            #stack[][0] = index of the name
            #stack[][1] = track the score
            stack.append((index, 0))
            continue

        # add to stack if index's score is less than stack's
        stacks_score = dict_points[participants[stack[-1][0]]]
        indexs_score = dict_points[participants[index]]

        if stacks_score >= indexs_score:
            stack.append((index, 0))
            continue

        # iterate through stack, update scores of stack
        while stack:
            top = stack.pop()
            # update score of final
            final_scores[top[0]] = (final_scores[top[0]][0], top[1])

            # update the next stack
            if stack != []:
                # update stack value by adding the score of the popped value
                total = stack[-1][1] + dict_points[participants[top[0]]] + top[1]
                stack[-1] = (stack[-1][0], total)

                # when the next score less than what's in stack, need to keep track
                #CHANGE IF STATEMENT
                if dict_points[participants[stack[-1][0]]] >= indexs_score:
                    break
        stack.append((index, 0))

    while stack:
        top = stack.pop()
        final_scores[top[0]] = (final_scores[top[0]][0], top[1])
        if stack != []:
            total = stack[-1][1] + dict_points[participants[top[0]]] + top[1]
            stack[-1] = (stack[-1][0], total)
        else:
            break

    return final_scores



