"""
CC5 Student Submission
Name:
"""

from typing import List, Tuple


def scooter_rentals(times: List[Tuple[int, int]]) -> int:
    """
    REPLACE
    Be sure to include :param: and :return: fields!
    See CC1 or Project 1 for examples of proper docstrings.
    """
    # List is empty
    if len(times) == 0:
        return 0

    # One time in list, return 1
    if len(times) == 1:
        return 1

    # multiple times in list
    final = 1

    # Guarantees: 0 <= x <= 5000
    # I just needed to make sure I had at least some thing turned in for my own sanity
    for i in range(0,5000):
        compare = 0
        i += 0.5
        for j in times:
            start = j[0]
            end = j[1]
            if start < i and i < end:
                compare += 1
        if compare > final:
            final = compare

    return final
