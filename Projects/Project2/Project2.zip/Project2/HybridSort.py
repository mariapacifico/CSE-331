"""
Your Name:
Project 2 - Hybrid Sorting
CSE 331 Fall 2021
Professor Sebnem Onsay
"""
import random
from typing import TypeVar, List, Callable, Tuple, Dict

T = TypeVar("T")  # represents generic type

def merge (S1, S2, S, comparator):
    """

    :param S1:
    :param S2:
    :param S:
    :return:
    """
    i = j = 0
    while i + j < len(S):
        if j == len(S2) or (i < len(S1) and comparator(S1[i], S2[j])):
            #i < len(S1) and S1[i] < S2 [j]):
            S[i + j] = S1[i]
            i += 1
        else:
            S[i + j] = S2[j]
            j += 1

def merge_sort(data: List[T], threshold: int = 0,
               comparator: Callable[[T, T], bool] = lambda x, y: x <= y) -> int:
    """
    INSERT DOCSTRING HERE
    """
    n = len(data)

    if n == threshold:
        insertion_sort(data, comparator)

    if n < 2:
        return
    mid = n // 2
    data1 = data[0:mid]
    data2 = data[mid:n]
    merge_sort(data1, threshold, comparator)
    merge_sort(data2, threshold, comparator)
    merge(data1, data2, data, comparator)

#https://d2l.msu.edu/d2l/le/content/1493941/viewContent/11043899/View?ou=1493941
def insertion_sort(data: List[T], comparator: Callable[[T, T], bool] = lambda x, y: x <= y) -> None:
    """
    INSERT DOCSTRING HERE
    """
    for i in range(1, len(data)):
        j = i
        while j > 0 and comparator(data[j], data[j-1]):
            temp = data[j]
            data[j] = data[j-1]
            data[j-1] = temp
            j = j -1


def hybrid_sort(data: List[T], threshold: int,
                comparator: Callable[[T, T], bool] = lambda x, y: x <= y) -> None:
    """
    INSERT DOCSTRING HERE
    """
    merge_sort(data, threshold, comparator)

#https://d2l.msu.edu/d2l/le/content/1493941/viewContent/11335929/View?ou=1493941
def binary_search(data, target, low, high):
    if low > high:
        return False
    else:
        mid = (low + high) // 2
        if target == data[mid]:
            return mid
        elif target < data[mid]:
            return binary_search(data, target, low, mid - 1)
        else:
            return binary_search(data, target, mid + 1, high)


#https://stackoverflow.com/questions/337664/counting-inversions-in-an-array
#MAKE SURE THAT IT'S WITHIN RUNTIME!!
def inversions_count(data: List[T]) -> int:
    """
    INSERT DOCSTRING HERE
    """
    # Call merge_sort() on a copy of data to retrieve the inversion count.
    # Should call merge_sort() with no threshold, and the default comparator.
    copy_data = data.copy()
    merge_sort(copy_data)
    inversions = 0

    # https://stackoverflow.com/questions/337664/counting-inversions-in-an-array
    for i in range(len(data)):
        first = data[i]
        # log(n)
        index = binary_search(copy_data, first, 0, len(copy_data) - 1)
        inversions += index
        # O(n)
        copy_data.remove(first)

    return inversions





def reverse_sort(data: List[T], threshold: int) -> None:
    """
    INSERT DOCSTRING HERE
    """
    merge_sort(data, threshold, comparator=lambda x, y: x >= y)


# forward reference
Ship = TypeVar('Ship')

# DO NOT MODIFY THIS CLASS
class Ship:
    """
    A class representation of a ship
    """

    __slots__ = ['name', 'x', 'y']

    def __init__(self, name: str, x: int, y: int) -> None:
        """
        Constructs a ship object
        :param name: name of the ship
        :param x: x coordinate of the ship
        :param y: y coordinate of the ship
        """
        self.x, self.y = x, y
        self.name = name

    def __str__(self):
        """
        :return: string representation of the ship
        """
        return "Ship: " + self.name + " x=" + str(self.x) + " y=" + str(self.y)

    __repr__ = __str__

    def __eq__(self, other):
        """
        :return: bool if two ships are equivalent
        """
        return self.x == other.x and self.y == other.y and self.name == other.name

    def __hash__(self):
        """
        Allows Ship to be used as a key in a dictionary (pretty cool, right?)
        :return: hash of string representation of the ship
        """
        return hash(str(self))

    def euclidean_distance(self, other: Ship) -> float:
        """
        returns the euclidean distance between `self` and `other`
        :return: float
        """
        return ((self.x - other.x) ** 2 + (self.y - other.y) ** 2) ** .5

    def taxicab_distance(self, other: Ship) -> float:
        """
        returns the taxicab distance between `self` and `other`
        :return: float
        """
        return abs(self.x - other.x) + abs(self.y - other.y)


# MODIFY BELOW
def navigation_test(ships: Dict[Ship, List[Ship]], euclidean: bool = True) -> List[Ship]:
    """
    INSERT DOCSTRING HERE
    """
    pass
