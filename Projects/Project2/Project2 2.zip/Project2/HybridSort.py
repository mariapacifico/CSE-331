"""
Your Name:
Project 2 - Hybrid Sorting
CSE 331 Fall 2021
Professor Sebnem Onsay
"""
import random
from typing import TypeVar, List, Callable, Tuple, Dict

T = TypeVar("T")  # represents generic type

def merge (S1, S2, S, comparator):
    """

    :param S1:
    :param S2:
    :param S:
    :return:
    """
    inversion = 0
    i = j = 0

    while i + j < len(S):
        # no inversion
        if j == len(S2) or (i < len(S1) and comparator(S1[i], S2[j])):
            S[i + j] = S1[i]
            i += 1

        # # inversion occured
        else:
            inversion += len(S1) - i
            S[i + j] = S2[j]
            j += 1

    return inversion


def merge_sort(data: List[T], threshold: int = 0,
               comparator: Callable[[T, T], bool] = lambda x, y: x <= y) -> int:
    """
    INSERT DOCSTRING HERE
    """
    inversion = 0

    n = len(data)

    if n == threshold:
        insertion_sort(data, comparator)

    if n < 2:
        return

    mid = n // 2
    data1 = data[0:mid]
    data2 = data[mid:n]

    # varaibles used to increment inversion
    num1 = merge_sort(data1, threshold, comparator)
    num2 = merge_sort(data2, threshold, comparator)
    inversion += merge(data1, data2, data, comparator)

    # after first recursive calls are done add to inversion
    if num1 != None:
        inversion += num1

    # after second recursive calls are done add to inversion
    if num2 != None:
        inversion += num2

    return inversion

#https://d2l.msu.edu/d2l/le/content/1493941/viewContent/11043899/View?ou=1493941
def insertion_sort(data: List[T], comparator: Callable[[T, T], bool] = lambda x, y: x <= y) -> None:
    """
    INSERT DOCSTRING HERE
    """
    for i in range(1, len(data)):
        j = i
        while j > 0 and comparator(data[j], data[j-1]):
            temp = data[j]
            data[j] = data[j-1]
            data[j-1] = temp
            j = j -1


def hybrid_sort(data: List[T], threshold: int,
                comparator: Callable[[T, T], bool] = lambda x, y: x <= y) -> None:
    """
    INSERT DOCSTRING HERE
    """
    merge_sort(data, threshold, comparator)


def inversions_count(data: List[T]) -> int:
    """
    INSERT DOCSTRING HERE
    """
    copy_data = data.copy()
    return merge_sort(copy_data)


def reverse_sort(data: List[T], threshold: int) -> None:
    """
    INSERT DOCSTRING HERE
    """
    merge_sort(data, threshold, comparator=lambda x, y: x >= y)


# forward reference
Ship = TypeVar('Ship')

# DO NOT MODIFY THIS CLASS
class Ship:
    """
    A class representation of a ship
    """

    __slots__ = ['name', 'x', 'y']

    def __init__(self, name: str, x: int, y: int) -> None:
        """
        Constructs a ship object
        :param name: name of the ship
        :param x: x coordinate of the ship
        :param y: y coordinate of the ship
        """
        self.x, self.y = x, y
        self.name = name

    def __str__(self):
        """
        :return: string representation of the ship
        """
        return "Ship: " + self.name + " x=" + str(self.x) + " y=" + str(self.y)

    __repr__ = __str__

    def __eq__(self, other):
        """
        :return: bool if two ships are equivalent
        """
        return self.x == other.x and self.y == other.y and self.name == other.name

    def __hash__(self):
        """
        Allows Ship to be used as a key in a dictionary (pretty cool, right?)
        :return: hash of string representation of the ship
        """
        return hash(str(self))

    def euclidean_distance(self, other: Ship) -> float:
        """
        returns the euclidean distance between `self` and `other`
        :return: float
        """
        return ((self.x - other.x) ** 2 + (self.y - other.y) ** 2) ** .5

    def taxicab_distance(self, other: Ship) -> float:
        """
        returns the taxicab distance between `self` and `other`
        :return: float
        """
        return abs(self.x - other.x) + abs(self.y - other.y)


# MODIFY BELOW
def navigation_test(ships: Dict[Ship, List[Ship]], euclidean: bool = True) -> List[Ship]:
    """
    INSERT DOCSTRING HERE
    """
    mistake_list = []

    # iterate through each list with each ship
    for key in ships:
        value = ships[key]
        mistake = 0

        # get number of mistakes from merge_sort
        # comparater depends on whether we're using euclidean or taxicab
        if euclidean == True:
             mistake = merge_sort(value, 0, comparator=lambda x, y: x.euclidean_distance(key) <= y.euclidean_distance(key))

        else:
            mistake = merge_sort(value, 0,
                                   comparator=lambda x, y: x.taxicab_distance(key) <= y.taxicab_distance(key))

        # put into list
        mistake_list.append((mistake, key))

    # sort list based on first index
    merge_sort(mistake_list, threshold=0, comparator=lambda x, y: x[1].name <= y[1].name if x[0] == y[0] else x[0] <= y[0])

    # put into final list
    final_list = []

    for i in mistake_list:
        final_list.append(i[1])

    return final_list
